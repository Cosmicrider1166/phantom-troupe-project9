# A disclosed feasibility adaptation of the pinned WWW 2025 implementation.
# Original source stays embedded and archived byte-for-byte; this is NOT author parity.
def _feasible_replacement(ns):
    f=ns['df_test'];hist=ns['df'];k=ns['k'];I=ns['num_set_all_items']
    count=np.bincount(np.asarray(f.recommendation.to_list(),int).ravel(),minlength=I)
    donors=sorted(np.flatnonzero(count>0),key=lambda i:(-count[i],int(i)))
    replacements=sorted(range(I),key=lambda i:(count[i],i))
    for donor in donors:
        selected=ns['sort_by_index_most_pop'](f,int(donor))
        for item in replacements:
            if count[donor]-count[item]<=1:break
            permitted=[u for u in selected.index
                if item not in hist.at[u,'train'] and item not in hist.at[u,'valid']
                and item not in f.at[u,'recommendation']]
            if not permitted:continue
            preferred=[u for u in permitted if item in hist.at[u,'pure_test']]
            u=(preferred or permitted)[0]
            return selected.loc[u],int(item),int(donor)
    return None


def _adapt_author_generation(source):
    # Explicit copies remove ambiguous slice assignment; they do not suppress warnings.
    source=source.replace('user_w_k_rel_item = df.loc[df.pure_test.apply(len)==curr_k]',
                          'user_w_k_rel_item = df.loc[df.pure_test.apply(len)==curr_k].copy()')
    source=source.replace('lt_k = lt_k[lt_k.recommendation.apply(len)<k]',
                          'lt_k = lt_k.loc[lt_k.recommendation.apply(len)<k].copy()')
    old='''            if candidate_users_find_relevant.any():
                row_idx = candidate_users[candidate_users_find_relevant].index[0]'''
    new='''            if candidate_users.empty:
                # This unexposed item has no admissible current donor user.
                continue
            if candidate_users_find_relevant.any():
                row_idx = candidate_users[candidate_users_find_relevant].index[0]'''
    assert source.count(old)==1
    source=source.replace(old,new)
    begin='''                if candidate_users_find_relevant.any():'''
    end='''                selected_df = selected_df.drop(row.name)'''
    st=source.index(begin,source.index('while count_most > ceil'))
    en=source.index(end,st)
    source=source[:st]+'''                if candidate_users.empty:
                    choice = feasible_replacement()
                    if choice is None:
                        constraint_stop[0] = True
                        break  # constrained one-swap local optimum, NOT a global oracle
                    row, item, most_pop_item_in_rec = choice
                    new_most_pop_item_in_rec = most_pop_item_in_rec
                    selected_df = sort_by_index_most_pop(df_test, most_pop_item_in_rec)
                elif candidate_users_find_relevant.any():
                    row_idx = candidate_users[candidate_users_find_relevant].index[0]
                    row = selected_df.loc[row_idx]
                else:
                    row_idx = candidate_users.index[0]
                    row = selected_df.loc[row_idx]

'''+source[en:]
    return source
